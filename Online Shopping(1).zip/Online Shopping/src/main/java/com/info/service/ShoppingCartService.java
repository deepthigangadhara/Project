package com.info.service;

//import com.reljicd.exception.NotEnoughProductsInStockException;
//import com.reljicd.model.Product;

import java.math.BigDecimal;
import java.util.Map;

import com.info.model.Product;

public interface ShoppingCartService {

    void addProduct(Product product);

    void removeProduct(Product product);

    Map<Product, Integer> getProductsInCart();

	

	

    //void checkout() throws NotEnoughProductsInStockException;

    BigDecimal getTotal();
}
