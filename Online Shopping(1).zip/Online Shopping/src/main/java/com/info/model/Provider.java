package com.info.model;

public enum Provider {
	 LOCAL, GOOGLE

}
